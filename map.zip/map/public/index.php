<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;


require '../vendor/autoload.php';
require '../src/config/db.php';

$app = new \Slim\App;

$app->get('/home/{name}', function(Request $req, Response $res){
    $name = $req->getAttribute('name');
    $res->getBody()->write("hello, $name");
});

require '../src/routes/companies.php';

$app->run();