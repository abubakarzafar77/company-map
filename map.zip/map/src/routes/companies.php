<?php
header('Access-Control-Allow-Origin: *'); 
header('Access-Control-Allow-Methods: GET,POST,PUT,DELETE,OPTIONS'); 
header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With'); 
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app = new \Slim\App;

$app->get('/api/companies', function(Request $req, Response $res){
    // echo "api/companies loading";

    $sql = "SELECT * FROM companies";
    try{
        $db = new db();
        $conn = $db->connect();
        $stmt = $conn->query($sql);
        $companies = $stmt->fetchAll(PDO::FETCH_OBJ);
        $companies = json_encode($companies);
        echo $companies;
        
        $conn = null;
    }catch(PDOException $e){
        echo '{"error":{"text": '.$e->getMessage().'}}';
    }
});
$app->post('/api/company/add',function(Request $req, Response $res){

    $file_dir   = "../uploads/";
    $imageFileType = pathinfo($_FILES["selectFile"]["name"], PATHINFO_EXTENSION);

    $newFileName = round(microtime(true)) . '.' . $imageFileType;
    $file_path  =  $file_dir . $newFileName;
    $uploadOK = 1;

    // echo $mx=rand();

    // echo $newfilename;
    // exit();
    
    $check =  getimagesize($_FILES["selectFile"]["tmp_name"]);
    //check image is actual image or fake image 
    if($check !== false){
        // echo "File is an Image -" .$check['mime']. ". ";
        $uploadOK = 1;
    }else{
        $notImageError =  "File is not an Image. ";
        $error = $notImageError;
        $uploadOK = 0;
    }
    // Check file size

    if ($_FILES["selectFile"]["size"] > 1000000) {
        $sizeError = "Sorry, your file is too large.";
        $error = $sizeError;
        $uploadOk = 0;
    }
    //check if file already exists 
    if(file_exists($file_path)){
        $existsError = "Sorry! File is already exists.";
        $error = $existsError;
        $uploadOK = 0;
    }
    // check if uploadOk is set 0 by an error
    if($uploadOK == 0){
        //some error
    }else{
        if(move_uploaded_file($_FILES["selectFile"]["tmp_name"],$file_path)){
            $uploadOK == 1;
        }else{
            // echo '{"error":{"text":"sorry There was an error uploading your file"}}';
            $uploadOK = 0;
        }
    }
    if($uploadOK == 0){
        switch($error){
            case $sizeError:
                echo '{"error":{"text":'.$sizeError.'}}';
                break;
            case $notImageError:
                echo '{"error":{"text":'.$notImageError.'}}';
                break;
            case $existsError:
                echo '{"error":{"text":'.$existsError.'}}';
                break;
            default:
                echo '{"error":{"text":"sorry There was an error uploading your file"}}';
        }
        // if($existsError){
        //     echo '{"error":{"text":'.$existsError.'}}';
        // }elseif($notImageError){

        // }else{
        //     echo '{"error":{"text":"sorry There was an error uploading your file"}}';
        // }
    }else{
        // everything is OK so storing data in DB
        
        // $newFileName =  basename($_FILES["selectFile"]["name"]);
        $companyData =  $req->getParam('company');
        $companyData = json_decode($companyData);

        $company_name           = !empty($companyData->name)? $companyData->name : '-';
        $company_lat            = !empty($companyData->lat)? $companyData->lat : '-';
        $company_lng            = !empty($companyData->lng)? $companyData->lng : '-';
        $company_country        = !empty($companyData->country)? $companyData->country : '-';
        $company_province       = !empty($companyData->province)? $companyData->province : '-';
        $company_district       = !empty($companyData->district)? $companyData->district : '-';
        $company_city           = !empty($companyData->city)? $companyData->city : '-';
        $company_vicinity       = !empty($companyData->vicinity)? $companyData->vicinity : '-';
        $company_roadAndStreet  = !empty($companyData->roadAndStreet)? $companyData->roadAndStreet : '-';
        $company_postalCode     = !empty($companyData->postalCode)? $companyData->postalCode : '-';

        $company_image          = !empty($newFileName)? $newFileName : '-';

        
        $sql = "INSERT INTO companies (company_name,company_lat,company_lng,company_country,company_province,company_district,company_city,company_vicinity,company_roadAndStreet,company_postalCode,company_image)
        VALUES(:company_name,:company_lat,:company_lng,:company_country,:company_province,:company_district,:company_city,:company_vicinity,:company_roadAndStreet,:company_postalCode,:company_image)";

        try{
            $db = new db();
            $conn = $db->connect();
            $stmt = $conn->prepare($sql);

            $stmt->bindParam(':company_name',$company_name);
            $stmt->bindParam(':company_lat',$company_lat);
            $stmt->bindParam(':company_lng',$company_lng);
            $stmt->bindParam(':company_country',$company_country);
            $stmt->bindParam(':company_province',$company_province);
            $stmt->bindParam(':company_district',$company_district);
            $stmt->bindParam(':company_city',$company_city);
            $stmt->bindParam(':company_vicinity',$company_vicinity);
            $stmt->bindParam(':company_roadAndStreet',$company_roadAndStreet);
            $stmt->bindParam(':company_postalCode',$company_postalCode);
            
            $stmt->bindParam(':company_image',$company_image);

            $stmt->execute();

            echo '{"notice":{"text":"customer Added"}}';
        }catch(PDOException $e){
            echo '{"error":{"text":'.$e->getMessage().'}}';
        }
        $conn = null;
    }
});

// for image uploading 

$app->post('/api/company/uploadFile', function(Request $req , Response $res){
    // $body = $req->getBody();
    // echo print_r($body);
    $companyData =  $req->getParam('company');
    $companyData = json_decode($companyData);
    var_dump($companyData->lat);
    // $companyData = $req->getParam('company');
    //  print_r($companyData);
    // echo ;
    // echo $_FILES["selectFile"]["name"];
    // foreach ($_POST['company'] as $key => $value) {


        // echo $value;
    // }
    // echo print_r($_POST);
    exit();



    $target_dir = "../uploads/";
    $url = $_SERVER['REQUEST_URI'];
    $parts = explode('/',$url);
    $dir = "http://".$_SERVER['SERVER_NAME'];
    // echo $url; 
    for($i = 0; $i < count($parts)-1; $i++){
        $dir.=$parts[$i]."/";
    }


    //actual link
    $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

    $target_file =  $target_dir . basename($_FILES["selectFile"]["name"]);
    $uploadOK = 1;
    $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);

    // $check =  getimagesize($_FILES["selectFile"]["tmp_name"]);
    // echo "width = $check[0] <br>"; 
    // echo "height = $check[1] <br>"; 
    // echo "----- = $check[2] <br>";
    // echo " channels = ".$check['channels']." <br>"; 
    // echo "mime = ". $check['mime']." <br>"; 
    // print_r($check[0]);
    
    // if(isset($_POST['submit'])){
    //     $check =  getimagesize($_FILES["selectFile"]["tmp_name"]);
    //     if($check !== false){
    //         echo "File is an Image -" .$check['mime']. ". ";
    //         $uploadOK = 1;
    //     }else{
    //         echo "File is not an Image. ";
    //         $uploadOK = 1;
    //     }
    // }
    $check =  getimagesize($_FILES["selectFile"]["tmp_name"]);
    //check image is actual image or fake image 
    if($check !== false){
        // echo "File is an Image -" .$check['mime']. ". ";
        $uploadOK = 1;
    }else{
        echo "File is not an Image. ";
        $uploadOK = 0;
    }
    
    //check if file already exists 
    if(file_exists($target_file)){
        echo "Sorry! File is already exists.";
        $uploadOK = 0;
    }
    // Check file size
    /*
    if ($_FILES["selectFile"]["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }*/
    /*
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" ) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }
    */
    // check if uploadOk is set 0 by an error
    if($uploadOK == 0){
        echo "Sorry your file not uploaded";
        //if everything is ok . try to  upload file 
    }else{
        if(move_uploaded_file($_FILES["selectFile"]["tmp_name"],$target_file)){
            echo "The file is Uploaded !";
        }else{
            "sorry There was an error uploading your file";
        }
    }

});